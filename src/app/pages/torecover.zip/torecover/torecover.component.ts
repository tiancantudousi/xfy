import { Component, OnInit,Renderer2,ViewChild} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';

import storage from './../../service/storage'
import {BrokedataService} from './../../service/state/wastage.service'
import { EmitService } from 'src/app/service/middleman.service';
import * as _ from 'lodash';
import { PublicuseService } from 'src/app/service/http/publicuse.service';
import { HttpService } from 'src/app/service/http/http.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { debounceTime, map, switchMap } from 'rxjs/operators';


@Component({
  selector: 'app-torecover',
  templateUrl: './torecover.component.html',
  styleUrls: ['./torecover.component.scss']
})
export class TorecoverComponent implements OnInit {
    // @ViewChild('packageinput') input;
    public signshow:boolean=false;

    public  sign;
    public promptarr;

    public palcevalue;

    public de_deptid;

    public tempdata;

    public promptlist=[];
    private tempName;
    public indeterminate=false;
    public allChecked=false;
    public packname;
    public packs=[];
    public packscopy=[];


    // showlist:boolean=false;
    checktype:string="�����";
    validateForm: FormGroup;

    public bodydata=[];
    private resetobj;
    private timer;
    showtopul=false;
    userName;
    userId;
    deptId;
    deptName;
    searchChange$=new BehaviorSubject('');;

    constructor(private fb: FormBuilder,private brokedataservice:BrokedataService,private middleman:EmitService,private publiceservice:PublicuseService,private renderer:Renderer2, private service: HttpService) { 
      const message = storage.get('userMessage');
      this.userName = message['userName'];
      this.userId = message['userId'];
      this.deptId = message['deptId'];
      this.deptName = message['deptName'];
      this.bodydata=this.brokedataservice.toberecoverdata;
      this.tempdata=this.bodydata.slice();
      this.promptarr=storage.get('promptarr');
      _.forEach(this.tempdata,(item)=>{
        item.checked=false;
      })
    }
  
    ngOnInit():void {
      this.validateForm = this.fb.group({
        place:null
      });
      this.middleman.eventEmittable.emit(this.tempdata);
      // this.publiceservice.getulPackagesbetter().subscribe(res=>{
      //   this.packscopy=res.slice();
      //   // _.forEach(this.packscopy,(item)=>{
      //   //       item.name=item.bmc+item.py_code;
      //   // })
      //   this.packs=this.packscopy.slice();
      //   // console.log(res,'包内容');
      // })
      //包搜索功能
      // const getRandomNameList = (name: string) => this.service.getdata(this.getparmas(name)).pipe(map((res: any) => res.returnValue.rows));
      // const optionList$: Observable<string[]> = this.searchChange$.asObservable().pipe(debounceTime(500)).pipe(switchMap(getRandomNameList));
      // optionList$.subscribe(data => {
      //   console.log('搜索返回结果',data);
      // });
    }
    onChosePack(e){
      console.log(e,'选择结果');
      if(!e){
        this.tempdata=this.bodydata.slice();
        return;
      }
      this.tempdata=_.filter(this.bodydata,(item)=>{
          return e.bid==item.bid;
      })
    }
    onChoseKs(e){
      console.log(e,'ks');
      if(!e){
        this.tempdata=[].concat(this.bodydata);
        return;
    }
      this.tempdata=this.bodydata.filter((item)=>{
        // return item.ff_did==this.de_deptid; 
      return item.deptname==e.deptname;      
    })
   
    this.middleman.eventEmittempcount.emit(this.tempdata.length);
    this.signshow=false;
    }

    getparmas(val){
      return {
        method: 'getComboGrid',
        service: 'PopupService',
        Popup:{"type":"COMBOGRID_BPZ_ks"},
        "PageReq":{page:"1",rows:"10",q:val},
        LoginForm: {
          deptId: this.deptId,
          deptName: this.deptName,
          userId: this.userId,
          userName: this.userName
        }
      };
    }

  
    // choosepackage(item,e){
    //   e.stopPropagation();
    //   this.packname=item.bmc;
    //   this.showtopul=false;
    //   this.tempdata=_.filter(this.bodydata,(val)=>{
    //           return val.bmc==item.bmc;
    //     })
    // }
    // hideul(){
    //   if(this.showtopul){
    //     this.packname='';
    //     this.tempdata=this.bodydata;
    //   }
    //   this.showtopul=false;
     
    // }
    ngAfterViewInit(){
      // this.middleman.showloading.emit(false);
      // this.renderer.listen(this.input.nativeElement, 'focus',()=>{
      //   this.showtopul=true;
      //   console.log('input foucs');
      // })
    }
    hickeyopen(e){
      let reg = new RegExp(`${this.packname}`,"i");      
      this.packs=_.filter(this.packscopy,(item)=>{
       
        return reg.test(item.bmc)||reg.test(item.py_code);
      })
      console.log(this,this.packs,this.packname,'this.packs');
    }
    // packchange(){
    //   //保存第一次选定的值，用于第二次重置回去
    //   if(!this.packname){
    //     this.tempdata=this.bodydata;
    //     return;
    //   }
    //   if(this.resetobj){this.resetobj.name=this.resetobj.bmc+this.resetobj.py_code};
    //   if(this.timer){return;}
    //   this.timer=setTimeout(()=>{
    //     let choseitem=_.find(this.packscopy,{'bid':this.packname});
    //     if(!choseitem){
    //       return;
    //     }
    //     this.resetobj=choseitem;
    //     choseitem['name']=choseitem['bmc'];
    //     this.timer=null;
    //     this.tempdata=_.filter(this.bodydata,(item)=>{
    //          console.log(item,choseitem);
    //           return choseitem.bid==item.bid;
    //     })
    //   },200);
    //   console.log(this.packname,'packname');
    // }

    onKey(){
      let listarr=this.promptarr.filter((item)=>{
        let reg = new RegExp(`^${this.validateForm.value.place}`,"i");
        return reg.test(item.de_alph);
      });
      this.promptlist=[...listarr];
      if(this.promptlist.length>0){
        this.signshow=true;
        // this.sign=signobj['de_deptname'];
        // this.de_deptid=signobj['de_deptid'];
      }
      else{
        this.signshow=false;
        // this.sign=null;
        this.de_deptid='';
      }    
    }

  inputclick($event?:Event){
    this.tempdata=this.bodydata.filter((item)=>{
        // return item.ff_did==this.de_deptid; 
      return item.deptname==this.palcevalue;      
    })
    if(!this.palcevalue){
        this.tempdata=[].concat(this.bodydata);
    }
    this.middleman.eventEmittempcount.emit(this.tempdata.length);
    this.signshow=false;

    if($event){$event.stopPropagation();}
  }



  signchoose(item){
    this.palcevalue=item.de_deptname;
    this.de_deptid=item.de_deptid;
    this.signshow=false;
    this.inputclick();
  }

  mountdetail(value){
    this.checktype=value;
    console.log(value);
  }

 
  

  testvalue(value){
    let reg=/^[A-Z]$/;
    return  reg.test(value);
  }
  //全选效果
updateAllChecked(): void {
  this.indeterminate = false;
  if (this.allChecked) {
    this.tempdata.forEach(item => item.checked= true);
  } else {
    this.tempdata.forEach(item => item.checked = false);
  }
 }
 //单选
 updateSingleChecked(): void {
  if (this.tempdata.every(item => item.checked === false)) { 
    this.allChecked = false;
    this.indeterminate = false;
  } else if (this.tempdata.every(item => item.checked === true)) {
    this.allChecked = true;
    this.indeterminate = false;
  } else {
    this.indeterminate = true;
  }
 }
 
 

}
